using LingoEngine.Movies;

namespace LingoEngine.L3D.Core.Movies;

/// <summary>
/// Framework interface for 3D movies.
/// </summary>
public interface ILingoFrameworkMovie3D : ILingoFrameworkMovie
{
}

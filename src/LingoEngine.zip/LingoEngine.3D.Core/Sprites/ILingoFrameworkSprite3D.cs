using LingoEngine.FrameworkCommunication;

namespace LingoEngine.L3D.Core.Sprites;

/// <summary>
/// Framework interface for 3D sprites.
/// </summary>
public interface ILingoFrameworkSprite3D : ILingoFrameworkSprite
{
}

namespace LingoEngine.L3D.Core.Members;

using LingoEngine.Members;

public interface ILingoFrameworkMember3D : ILingoFrameworkMember
{
}

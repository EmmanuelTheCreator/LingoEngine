﻿namespace LingoEngine.L3D.Core.FrameworkCommunication
{
    public interface ILingo3DFrameworkFactory
    {
    }
}

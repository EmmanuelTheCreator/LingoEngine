# LingoEngine.Director.Core

Framework‑independent implementation of classic Director behaviours. These APIs mimic the original Director runtime and are consumed by framework adapters like `LingoEngine.Director.LGodot`.

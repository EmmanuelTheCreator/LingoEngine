﻿namespace LingoEngine.Director.Core.Events
{
    public interface IHasMenuItemSelectedEvent
    {
        void MenuItemSelected(string menuCode);
    }
}

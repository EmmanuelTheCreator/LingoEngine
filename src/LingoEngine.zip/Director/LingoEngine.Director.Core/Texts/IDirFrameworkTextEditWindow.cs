﻿using LingoEngine.Director.Core.Windows;

namespace LingoEngine.Director.Core.Texts
{
    public interface IDirFrameworkTextEditWindow : IDirFrameworkWindow { }
}

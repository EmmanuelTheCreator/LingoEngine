using LingoEngine.Director.Core.Windows;

namespace LingoEngine.Director.Core.Importer
{
    public class DirectorImportExportWindow : DirectorWindow<IDirFrameworkImportExportWindow>
    {
    }
}

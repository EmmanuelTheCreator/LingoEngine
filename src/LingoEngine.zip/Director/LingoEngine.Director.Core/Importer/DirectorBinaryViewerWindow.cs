using LingoEngine.Director.Core.Inspector;
using LingoEngine.Director.Core.Windows;

namespace LingoEngine.Director.Core.Importer
{
    public class DirectorBinaryViewerWindow : DirectorWindow<IDirFrameworkBinaryViewerWindow>
    {
    }
}

﻿using LingoEngine.Director.Core.Windows;
using LingoEngine.Gfx;

namespace LingoEngine.Director.Core.Gfx
{
    public interface IDirFrameworkMainMenuWindow : IDirFrameworkWindow 
    {
      
    }
}

using LingoEngine.Director.Core.Windows;

namespace LingoEngine.Director.Core.Gfx
{
    public class DirectorToolsWindow : DirectorWindow<IDirFrameworkToolsWindow>
    {
    }
}

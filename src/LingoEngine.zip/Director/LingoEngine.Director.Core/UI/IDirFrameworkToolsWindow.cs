﻿using LingoEngine.Director.Core.Windows;

namespace LingoEngine.Director.Core.Gfx
{
    public interface IDirFrameworkToolsWindow : IDirFrameworkWindow { }
}

using LingoEngine.Director.Core.Windows;

namespace LingoEngine.Director.Core.Projects
{
    public class DirectorProjectSettingsWindow : DirectorWindow<IDirFrameworkProjectSettingsWindow>
    {
    }
}

﻿using LingoEngine.Director.Core.Windows;

namespace LingoEngine.Director.Core.Projects
{
    public interface IDirFrameworkProjectSettingsWindow : IDirFrameworkWindow { }
}

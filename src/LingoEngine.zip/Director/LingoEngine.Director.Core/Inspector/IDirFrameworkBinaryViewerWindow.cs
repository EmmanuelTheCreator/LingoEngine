﻿using LingoEngine.Director.Core.Windows;

namespace LingoEngine.Director.Core.Inspector
{
    public interface IDirFrameworkBinaryViewerWindow : IDirFrameworkWindow { }
}

using LingoEngine.Director.Core.Windows;

namespace LingoEngine.Director.Core.Stages
{
    public class DirectorStageWindow : DirectorWindow<IDirFrameworkStageWindow>
    {
    }
}

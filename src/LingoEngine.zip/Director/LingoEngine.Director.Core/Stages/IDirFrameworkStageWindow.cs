﻿using LingoEngine.Director.Core.Windows;

namespace LingoEngine.Director.Core.Stages
{
    public interface IDirFrameworkStageWindow : IDirFrameworkWindow { }
}

using LingoEngine.Director.Core.Windows;

namespace LingoEngine.Director.Core.Scores
{
    public class DirectorScoreWindow : DirectorWindow<IDirFrameworkScoreWindow>
    {
        public DirectorScoreWindow() : base() { }
    }
}

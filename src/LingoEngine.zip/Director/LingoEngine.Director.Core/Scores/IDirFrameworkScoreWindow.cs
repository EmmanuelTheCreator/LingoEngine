﻿using LingoEngine.Director.Core.Windows;

namespace LingoEngine.Director.Core.Scores
{
    public interface IDirFrameworkScoreWindow : IDirFrameworkWindow { }
}

# LingoEngine.Director.LGodot

Godot front‑end for the Director API. This package binds Director style components to Godot nodes, allowing existing Lingo content to run inside the Godot engine.

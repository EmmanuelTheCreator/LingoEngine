namespace LingoEngine.IO.Data.DTO;

public struct LingoPointDTO
{
    public float X { get; set; }
    public float Y { get; set; }
}

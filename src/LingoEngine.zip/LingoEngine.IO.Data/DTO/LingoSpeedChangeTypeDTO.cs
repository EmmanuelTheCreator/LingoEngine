namespace LingoEngine.IO.Data.DTO;

public enum LingoSpeedChangeTypeDTO
{
    Sharp,
    Smooth
}

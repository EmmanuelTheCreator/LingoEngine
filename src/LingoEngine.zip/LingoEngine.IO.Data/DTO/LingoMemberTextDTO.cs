

namespace LingoEngine.IO.Data.DTO;

public class LingoMemberTextDTO : LingoMemberDTO
{
    public string Text { get; set; } = string.Empty;
}

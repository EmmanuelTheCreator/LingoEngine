

namespace LingoEngine.IO.Data.DTO;

public class LingoMemberPictureDTO : LingoMemberDTO
{
    public string? ImageFile { get; set; }
}

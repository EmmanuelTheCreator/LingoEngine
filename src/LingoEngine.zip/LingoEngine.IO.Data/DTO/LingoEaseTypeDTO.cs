namespace LingoEngine.IO.Data.DTO;

public enum LingoEaseTypeDTO
{
    Linear,
    EaseIn,
    EaseOut,
    EaseInOut
}

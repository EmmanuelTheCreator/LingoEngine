namespace LingoEngine.IO.Data.DTO;

public enum PreLoadModeTypeDTO
{
    WhenNeeded = 0,
    BeforeFrame1,
    AfterFrame1
}

﻿namespace LingoEngine.Xtras
{
    public interface ILingoXtra
    {
        public string Name { get; }
    }
}

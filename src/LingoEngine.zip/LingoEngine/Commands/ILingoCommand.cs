namespace LingoEngine.Commands;

public interface ILingoCommand { }

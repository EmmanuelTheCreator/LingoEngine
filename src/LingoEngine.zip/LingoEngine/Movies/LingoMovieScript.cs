﻿using LingoEngine.Core;

namespace LingoEngine.Movies
{
    public class LingoMovieScript : LingoScriptBase
    {
        public LingoMovieScript(ILingoMovieEnvironment env) : base(env)
        {
        }
    }
}

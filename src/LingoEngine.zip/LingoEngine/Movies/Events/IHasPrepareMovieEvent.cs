﻿namespace LingoEngine.Movies.Events
{
    public interface IHasPrepareMovieEvent
    {
        void PrepareMovie();
    }

}

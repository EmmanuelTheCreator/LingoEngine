﻿namespace LingoEngine.Movies.Events
{
    public interface IHasExitFrameEvent
    {
        void ExitFrame();
    }

}

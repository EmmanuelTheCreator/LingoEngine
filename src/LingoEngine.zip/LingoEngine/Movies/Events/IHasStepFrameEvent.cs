﻿namespace LingoEngine.Movies.Events
{
    public interface IHasStepFrameEvent
    {
        void StepFrame();
    }

}

﻿namespace LingoEngine.Movies.Events
{
    public interface IHasStartMovieEvent
    {
        void StartMovie();
    }

}

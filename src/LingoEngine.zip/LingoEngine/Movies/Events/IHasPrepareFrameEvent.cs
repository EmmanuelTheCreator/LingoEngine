﻿namespace LingoEngine.Movies.Events
{
    public interface IHasPrepareFrameEvent
    {
        void PrepareFrame();
    }

}

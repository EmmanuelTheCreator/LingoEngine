﻿namespace LingoEngine.Movies.Events
{
    public interface IHasStopMovieEvent
    {
        void StopMovie();
    }

}

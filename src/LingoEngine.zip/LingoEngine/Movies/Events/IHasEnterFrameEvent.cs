﻿namespace LingoEngine.Movies.Events
{
    public interface IHasEnterFrameEvent
    {
        void EnterFrame();
    }

}

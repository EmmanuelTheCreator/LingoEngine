namespace LingoEngine.Animations
{
    public enum LingoEaseType
    {
        Linear,
        EaseIn,
        EaseOut,
        EaseInOut
    }
}

﻿using LingoEngine.Movies;

namespace LingoEngine.Core
{
    public class LingoParentScript : LingoScriptBase
    {
        public LingoParentScript(ILingoMovieEnvironment env) : base(env)
        {
        }
    }
}

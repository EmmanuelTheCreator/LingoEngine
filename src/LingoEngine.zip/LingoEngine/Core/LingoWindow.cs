﻿namespace LingoEngine.Core
{
    public interface ILingoWindow
    {

    }
    internal class LingoWindow : ILingoWindow
    {
    }
}

﻿namespace LingoEngine.Sprites.Events
{
    public interface IHasBeginSpriteEvent
    {
        void BeginSprite();
    }

}

﻿namespace LingoEngine.Sprites.Events
{
    public interface IHasEndSpriteEvent
    {
        void EndSprite();
    }

}

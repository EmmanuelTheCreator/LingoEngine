﻿namespace LingoEngine.Texts
{
    public interface ILingoMemberText : ILingoMemberTextBase
    {
    }

}

 


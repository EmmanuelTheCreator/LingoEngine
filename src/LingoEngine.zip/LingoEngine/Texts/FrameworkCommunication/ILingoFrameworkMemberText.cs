﻿namespace LingoEngine.Texts.FrameworkCommunication
{
    public interface ILingoFrameworkMemberText : ILingoFrameworkMemberTextBase
    {


    }
}

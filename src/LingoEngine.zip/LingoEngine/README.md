# LingoEngine Core

Contains the language runtime and high level abstractions used across all framework adapters.

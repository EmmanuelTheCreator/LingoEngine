﻿using LingoEngine.Inputs;

namespace LingoEngine.Inputs.Events
{



    public interface IHasFocusEvent
    {
        void Focus();
    }

}

﻿using LingoEngine.Inputs;

namespace LingoEngine.Inputs.Events
{
    public interface IHasKeyDownEvent
    {
        void KeyDown(ILingoKey mouse);
    }
}

﻿namespace LingoEngine.Inputs.Events
{
    public interface IHasBlurEvent
    {
        void Blur();
    }

}

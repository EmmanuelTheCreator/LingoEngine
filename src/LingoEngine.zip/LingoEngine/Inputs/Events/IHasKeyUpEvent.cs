﻿namespace LingoEngine.Inputs.Events
{
    public interface IHasKeyUpEvent
    {
        void KeyUp(ILingoKey mouse);
    }
}

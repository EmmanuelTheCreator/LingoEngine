namespace LingoEngine.Shapes
{
    public enum LingoShapeType
    {
        Rectangle = 1,
        RoundRect = 2,
        Oval = 3,
        Line = 4
    }
}

# Macromedia Lingo in c# : With the Godot framework

## Package: LingoEngine.LGodot

Adapter layer that plugs the core Lingo runtime into Godot. It implements the interfaces defined in `src/LingoEngine` using Godot nodes and resources.

See [docs/GodotSetup.md](../../docs/GodotSetup.md) for build instructions and example code.

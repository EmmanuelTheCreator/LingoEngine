﻿namespace LingoEngine.Lingo.Core.Tokenizer
{
    public class LingoScript
    {
        public string Source { get; internal set; } = "";
    }
}